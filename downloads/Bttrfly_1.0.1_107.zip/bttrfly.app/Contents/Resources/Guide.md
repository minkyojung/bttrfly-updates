## Quick Guide for Bttrfly 🦋

### Bttrfly is a *local‑first Markdown notebook*.


#### Get started
- [ ] **New note:** Press ⌘N or click the **＋** button  
- [ ] **Write freely:** Every keystroke is auto‑saved  
- [ ] **Already using Obsidian (or any local `.md` vault)?** Add that folder to the **'Search Panel'** for one‑click access  
- [ ] **Quick switch:** Press ⌘P to find any note instantly  
- [ ] **Settings:** Press ⌘, to customize the app

### Now, hit ⌘N or ⌘P to start journey!
